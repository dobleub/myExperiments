#Listado 3: funci�n �prueba()�.
def prueba(sudoku, asignadas, fila, col):
    # Puede dar 3 cosas:
    # a) [] si est� ocupado
    # b) tupla con n�meros posibles
    # c) [-1] si es imposible

    if sudoku[fila][col] != 0:
        return []

    else:
        resultado = []

        # probamos todos los n�meros posibles
        for n in range(1,LINEAS+1):

            existe = False

            # barremos lineas
            for l in range(0,LINEAS):
                if sudoku[l][col] == n:
                    existe = True
                    break

            # barremos columnas
            for c in range(0,COLUMNAS):
                if sudoku[fila][c] == n:
                    existe = True
                    break
            # Buscamos en las posiciones asignadas
            for asig in asignadas:
                if asig[0] == fila and asig[2] == n:
                    existe = True
                    break
                if asig[1] == col and asig[2] == n:
                    existe = True
                    break

            if not existe:
                resultado.append(n)

        if resultado == []:
            # Un callej�n sin salida
            resultado = [-1]

        return resultado
#Listado 1: clase �Posicion()�.
class Posicion:
    ### Gestiona una posici�n, controlando los incrementos
    ###
    def __init__(self,maxfila,maxcol):
        self.maxfila = maxfila
        self.maxcol = maxcol
        self.fila = 0
        self.col = 0

    def setFila(self, fila):
        if fila < 0:
            self.fila = 0
        elif fila >= self.maxfila:
            self.fila = -1
        else:
            self.fila = fila

    def setCol(self, col):
        if col < 0:
            self.col = 0
        elif col >= self.maxcol:
            self.col = -1
        else:
            self.col = col

    def getFila(self):
        return self.fila

    def getCol(self):
        return self.col

    def fin(self):
        return self.fila == -1 and self.col == -1

    def reset(self):
        self.fila = 0
        self.col = 0

    def sig(self):
        # Incrementa la posici�n controlando que no se pasa
        # del final.
        if not self.fin():
            self.col += 1
            if self.col == self.maxcol:
                self.col = 0
                self.fila +=1
                if self.fila == self.maxfila:
                    self.fila = -1
                    self.col = -1

    def getPos(self):
        return [self.fila, self.col]
#Listado 2: funci�n �imprime()�.
def imprime(sudoku, asignadas):
    barra = ""
    for i in range(0,COLUMNAS):
        barra += "�---"
    barra += "."

    print barra
    for fila in range(0,len(sudoku)):
        cadena = ""
        for columna in range(0,len(sudoku)):
            if sudoku[fila][columna] == 0:
                encontrado = False
                for a in asignadas:
                    if a[0] == fila and a[1] == columna:
                        cadena += "| "+ str(a[2]) + " "
                        encontrado = True
                if not encontrado:
                    cadena += "|"+"   "
            else:
                cadena += "| "+str(sudoku[fila][columna])+" "
        cadena += "|"
        print cadena
        print barra
#Listado 4: funci�n �resuelve()�
def resuelve(sudoku):

    MAXLINEAS = len(sudoku)
    MAXCOLS = MAXLINEAS

    # Comenzamos en [0,0]
    pos = Posicion(MAXLINEAS,MAXCOLS)

    pilaActual = []
    pilaPosibles = []

    while not pos.fin():
        posibles = prueba(sudoku,pilaActual,pos.getFila(),pos.getCol())

        while posibles == []:
            if pos.fin():
                # Hemos llegado al fin
                imprime(sudoku,pilaActual)
                return True
            pos.sig()
            posibles = prueba(sudoku,pilaActual,pos.getFila(),pos.getCol())

        if posibles == [-1]:
            # Backtracking
            estado = pilaActual.pop()
            while estado[0] != pilaPosibles[-1][0] or estado[1] != pilaPosibles[-1][1]:
                estado = pilaActual.pop()
            # Ahora los �ltimos estados de ambas tienen la misma posici�n
            pilaActual.append(pilaPosibles.pop())
            # Ponemos la posici�n correcta
            pos.setFila(pilaActual[-1][0])
            pos.setCol(pilaActual[-1][1])

        else:
            # Aqu� tenemos unas posibles
            # Cojemos la primera y la apilamos en pilaActual, y el resto en pilaPosibles
            for posible in posibles[1:]:
                pilaPosibles.append([pos.getFila(),pos.getCol(),posible])

            pilaActual.append([pos.getFila(),pos.getCol(),posibles[0]])

        pos.sig()

def existe(sudoku, num, linea, col):
    encontrado = False
    for l in range(0,LINEAS):
        if sudoku[l][col] == num:
            encontrado = True

    for c in range(0,COLUMNAS):
        if sudoku[linea][c] == num:
            encontrado = True
    return encontrado
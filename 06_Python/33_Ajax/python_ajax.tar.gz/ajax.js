// GLOBALES
var http_request = false;

function hazPeticion(url) {

  http_request = false;

  http_request= new XMLHttpRequest();

  if (http_request.overrideMimeType) {
    http_request.overrideMimeType('text/xml');
  }

  if (!http_request) {
    alert('Error al crear la instancia de XMLHttpRequest.');
    return false;
  }

  // Esto es un callback, que se dispara al terminar de
  // descargar el fichero xml.
  http_request.onreadystatechange = modificaContenido;
  http_request.open('GET', url, true);
  http_request.send(null);
}
// Elimina todo elemento con id "linea"
function vaciaContenido(){
  var d = document.getElementById("contenedor");
  while(document.getElementById("linea0") || 
	document.getElementById("linea1")){
    nodo = document.getElementById("linea0");
    if (! nodo){
      nodo = document.getElementById("linea1");
    }
    var nodo_basura = d.removeChild(nodo);
  }
}


// Carga el resultado del XML
function modificaContenido() {
  if (http_request.readyState == 4) {
    if (http_request.status == 200) {
      vaciaContenido();


      var xmldoc =   http_request.responseXML;
      var root = xmldoc.getElementsByTagName('salida').item(0);          

      var fondo = 0;
 
      for(var i = 0; i < root.childNodes.length; i++){
	var nodo = root.childNodes.item(i);
	
	var contenedor = document.getElementById("contenedor");
	var p = document.createElement("p");

	// Truco para los colores ;)
	if (fondo == 0) { 
	  p.setAttribute("id","linea0");}
	else { 
	  p.setAttribute("id","linea1");
	}
	fondo = 1 - fondo;

	var titulo = document.getElementById("datos");
	p.textContent = nodo.firstChild.data;

	contenedor.insertBefore(p,titulo);
      }
      
    } else {
      alert('Hubo un problema con la petici�n.');
    }
  }
}




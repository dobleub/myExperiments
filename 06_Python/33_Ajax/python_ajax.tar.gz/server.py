#!/usr/local/bin/python

import BaseHTTPServer
import os
import cgi


class AJAXHTTPRequestHandler (BaseHTTPServer.BaseHTTPRequestHandler):
    """
    Responde a peticiones HTTP
    """
    def do_GET(self):
        "Gestiona los GET"

        acciones = {
            "/" :       ["envia_fichero","index.html"],
            "/ps.xml" : ["envia_comando", "ps afx"],
            "/df.xml":  ["envia_comando", "df"],
            "/who.xml": ["envia_comando","who"],
            "/uname.xml": ["envia_comando","uname -a"]}
        
        if self.path in acciones.keys():
            accion = acciones[self.path]
            (getattr(self,accion[0]))(self.path,accion[1])
        else:
            if (self.path[-3:]  == ".js" or
                self.path[-4:]  == ".css"):
                self.envia_fichero("",self.path[1:])

            else:
                self.envia_fichero("","404.html")
            


    def envia_fichero(self,ruta,fichero):
        # No usamos ruta, pero as� simplificamos el c�digo
        p = Pagina(fichero)
        self.enviar_respuesta(p.tipo(), p.contenido())
            
    def envia_comando(self,ruta,comando):
        c = Comando(comando)
        self.enviar_respuesta(c.tipo(), c.contenido())

    def enviar_respuesta(self, tipo, contenido):
        self.enviar_cabecera(tipo)
        self.wfile.write(contenido)
    
    def enviar_cabecera(self, tipo):
        self.send_response(200)
        self.send_header("Content-type","text/" + tipo)
        self.end_headers()


class Pagina:
    def __init__(self,nombre):
        self.nombre = nombre
        self.texto = ""
        fichero = file(self.nombre)
        self.texto = fichero.read()
        fichero.close()

    def contenido(self):
        return self.texto

    def tipo(self):
        tipo = "html"
        ext = self.nombre[-4:]
        if (ext == "html"):
            tipo = "html"
        elif (ext == ".xml"):
            tipo = "xml"
        elif (ext == ".css"):
            tipo = "css"
        return tipo

        
class Comando:
    def __init__(self,comando):
        self.tuberia = os.popen(comando)
        self.xml = ""
        
    def contenido(self):
        # fichero XML
        if not self.xml:
            self.xml = "<?xml version=\"1.0\" ?>"
            self.xml += "<salida>"
            linea = self.tuberia.readline()[:-1] # para quitar el \n
            while linea:
                self.xml += "<linea>" + cgi.escape(linea) + "</linea>"
                linea = self.tuberia.readline()[:-1]
            self.xml += "</salida>"
        return self.xml

    def tipo(self):
        return "xml"





def test(HandlerClass = AJAXHTTPRequestHandler,
         ServerClass = BaseHTTPServer.HTTPServer):
    BaseHTTPServer.test(HandlerClass, ServerClass)

if __name__ == '__main__':
    test()

import uno
import unohelper

import random
import time
import httplib
import csv

from com.sun.star.task import XJobExecutor

def getSimbolo(simbolo):
    c = httplib.HTTPConnection("finance.yahoo.com")
    c.request("GET","/d/quotes.csv?s="+simbolo+"&f=sl1d1t1c1ohgv&e=.csv")
    r = c.getresponse()
    cad = r.read()
    reader = csv.reader([cad])
    resultado = []
    for row in reader:
        resultado = row
    return resultado

class StockJob( unohelper.Base, XJobExecutor ):
    def __init__( self, ctx ):

        self.ctx = ctx

    def trigger( self, args ):
        desktop = self.ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.frame.Desktop", self.ctx )

        model = desktop.getCurrentComponent()
        
        self.hojas = model.getSheets()
        
        self.s1 = self.hojas.getByIndex(0)

        simbolos = ["GOOG","MSFT","RHAT"]
        i = 0;

        for s in simbolos:
            self.actualiza(getSimbolo(s),i)
            i = i + 1 

    def actualiza(self, cotizacion, fila):
        i = 0
        for entrada in cotizacion:
            if (i == 0) or (i == 2) or (i ==3):
                self.s1.getCellByPosition(i,fila).setString(entrada)
            else:
                self.s1.getCellByPosition(i,fila).setValue(float(entrada))
                
            i = i + 1

g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation( StockJob,
                                          "org.openoffice.comp.pyuno.linuxmagazine.Stock",
                                          ("com.sun.star.task.Job",),)
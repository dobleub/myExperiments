The Itcluno Package

unospection is a tool for introspection of OpenOffice.org objects and uses the tcluno package by Arnulf Wiedemann.

To use this package you should be familiar with OpenOffice library routines.

A brief introduction for using this tool is given at:
http://www.tugm.de/Projekte/TCLUNO/introspection/using_introspection.html (in german)
http://www.tugm.de/Projekte/TCLUNO/introspection/using_introspection.html.en (in english)

start this tool with the following command:
tclsh unospection.tcl

#!/usr/local/bin/python

# Listado 6: cuaderno.py

# -*- coding: ISO8859-1 -*-

import curses
import curses.ascii
import curses.textpad
import time
import os.path
import string
import sys
import almacen
    
        
class GUI:
    """Interfaz con el usuario."""
    
    def __init__(self,datos):

        self.registra_comandos()

        self.datos = datos
        self.pos_fechas = len(self.datos) - 1
        
        self.genera_ventanas()

        self.banner("-- [n] nueva | [e] editar  | [q] salir  --")

        self.dibuja_fechas()

        self.refresca()

    def genera_ventanas(self):
        "Genera las ventanas iniciales"
        self.scr_fechas =  stdscr.subwin(23, 80, 0, 0)
        self.scr_info = stdscr.subwin(1,80,23,0)


    def registra_comandos(self):
        "Almacena la letra y el comando asociado"
        self.comandos = [['d','borrar'],
                         ['e','editar'],
                         ['n','nueva_entrada'],
                         ['q','salir'],
                         ['s',"estado"]]

    def ejecuta_comando(self, ch):
        "Procesa las teclas recibidas"
        if curses.ascii.isprint(ch):
            for comando in self.comandos:
                if comando[0] == chr(ch):
                    (getattr(self,comando[1]))()
                    break
        else:
            if ch in (curses.ascii.DLE, curses.KEY_UP):
                self.incr_pos_fechas()
                self.redibuja()
            elif ch in (curses.ascii.SO, curses.KEY_DOWN):
                self.decr_pos_fechas()
                self.redibuja()
                
        self.refresca()
        return 1


    def fecha(self):
        return time.strftime("%Y-%m-%d %H:%M")

    def long_fecha(self):
        caja_texto = 2 # el | izquierdo  y el | derecho
        return len(self.fecha()) + caja_texto
        
    def long_linea_texto(self):
        return (80 - self.long_fecha())


    def banner(self, texto):
        "Muestra el texto en la zona de banner"
        self.scr_info.clear()
        self.scr_info.addstr(texto, curses.A_BOLD)
        self.scr_info.refresh()

        
    def dibuja_fechas(self):
        "Genera el listado de fechas de la izquierda"
        

        self.scr_fechas.clear()
        pos_x = 3

        # 8 elementos por arriba y abajo
        min = self.pos_fechas - 8
        max = self.pos_fechas + 8

        
        if max > len(self.datos):
            max = len(self.datos)
            min = min + (max - len(self.datos))
        if min < 0:
            max = max + ( -min)
            min = 0 

        if len(self.datos) > 0:

            # Marcamos con negrita la fecha sobre la que est� el curso
            # para ello iteramos escribiendo las fechas y cuando la
            # encontramos le pasamos el atributo de negrita
            fechas = self.listado_fechas()
            for fecha in fechas[min:max]:

                fecha_temp = "["+fecha+"]  "

                if fechas[self.pos_fechas] == fecha:
                    # Hemos encontrado nuestra fecha!!!
                    self.scr_fechas.addstr(pos_x,1,fecha_temp , curses.A_BOLD | curses.A_UNDERLINE)
                   
                else:
                    self.scr_fechas.addstr(pos_x,1,fecha_temp, 0)
                
                self.scr_fechas.addstr(pos_x,len(fecha_temp),self.datos[fecha],0)
                pos_x = pos_x + 1

        self.refresca()

    def editar(self):
        "Muestra un cuadro para introducir el texto y lo guarda"
        if len(self.datos) == 0:
            return
        else:
            self.banner("� EDITANDO ! --   [control+g]  guardar | [q] salir  --")
            fechas = self.listado_fechas()
            texto = self.datos[fechas[self.pos_fechas]]
            self.refresca()
            
            # Capturamos el nuevo  texto.

            ncols, nlineas = 25, 4
            uly, ulx = 15, 20
            stdscr.addstr(uly-2, ulx, "Usa Ctrl-G para guardar.")
            win = curses.newwin(nlineas, ncols, uly, ulx)
            curses.textpad.rectangle(stdscr, uly-1, ulx-1, uly + nlineas, ulx + ncols)
            stdscr.refresh()
            nuevo_texto= curses.textpad.Textbox(win).edit()
            stdscr.refresh()

            nuevo_texto = nuevo_texto.replace('\n','')
            # Guardamos el nuevo texto
            self.datos[fechas[self.pos_fechas]] = nuevo_texto
            
            self.banner("-- [n] nueva | [e] editar  | [q] salir  --")

    def borrar(self):
        "Elimina la entrada seleccionada"
        if len(self.datos) > 0:
            fechas = self.listado_fechas()
            del self.datos[fechas[self.pos_fechas]]
            self.actualiza_pos_fechas()
            self.redibuja()
            self.refresca()

    def redibuja(self):
        "Redibuja la pantalla"
        self.dibuja_fechas()
        self.refresca()

    def refresca(self):
        self.scr_fechas.refresh()

    def listado_fechas(self):
        "Devuelve el listado de fechas ordenado"
        fechas = self.datos.entradas()
        fechas.sort(reverse=-1)
        return fechas

    def decr_pos_fechas(self):
        "Mueve la fecha seleccionada hacia arriba"
        if self.pos_fechas >= (len(self.datos) - 1):
            self.pos_fechas = len(self.datos) - 1
        else:
            self.pos_fechas += 1

    def incr_pos_fechas(self):
        "Mueve la fecha seleccionada hacia abajo"
        if self.pos_fechas <= 0:
            self.pos_fechas = 0
        else:
            self.pos_fechas -= 1

    def actualiza_pos_fechas(self,fecha=""):
        "Realiza los cambios oportunos cuando se elimina una fecha"
        if fecha == "":
            self.decr_pos_fechas()
        else:
            fechas = self.listado_fechas()
            cont = 0
            resultado = 0
            for f in fechas:
                if f == fecha:
                    resultado = cont
                    break
                cont += 1
                
            self.pos_fechas = resultado

        self.redibuja()
        self.refresca()

    def nueva_entrada(self):
        "Introduce una nueva fecha"
        fechas = self.listado_fechas()
        fecha = self.fecha()
        if not fecha in fechas:
            self.datos[fecha] = "Texto vacio"
            self.actualiza_pos_fechas(fecha)
            self.redibuja()
            self.refresca()
            self.editar()
        
    def salir(self):
        cierra_curses(stdscr)
        sys.exit(0)
        
    def estado(self):
        "Muestra informaci�n general"
        cadena = ""
        fechas = self.listado_fechas()
        cont = 0
        for fecha in fechas:
            cadena += "["+str(cont)+">"+fecha+"]"
            cont += 1

        cadena = "[P:"+str(self.pos_fechas)+"]"+"--[L:"+str(len(self.datos))+"]" + cadena
        self.banner(cadena)

class Diario:
    def __init__(self):
        self.datos = almacen.Almacen('diario')
        self.gui = GUI(self.datos)
        self.bucle_infinito()
        
    def bucle_infinito(self):
        while 1:
            c = stdscr.getch()
            n = self.gui.ejecuta_comando(c)
            if not n:
                break

def arranca_curses(stdscr):
    curses.noecho()
    curses.cbreak()
    stdscr.keypad(1)

def cierra_curses(stdscr):
    stdscr.keypad(0)
    curses.echo()
    curses.nocbreak()
    curses.endwin()                 

if __name__=='__main__':
    stdscr=curses.initscr()
    arranca_curses(stdscr)
    diario = Diario()
    cierra_curses(stdscr)
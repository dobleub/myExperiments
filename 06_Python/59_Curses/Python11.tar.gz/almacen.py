#!/usr/local/bin/python

# Listado 2: almacen.py

import dbm
class Almacen:
    def __init__ (self,nombre):
        self.bd = dbm.open(nombre,'c')

    def busca_palabra (self, palabra):
        claves = self.entradas()
        encontradas = []
        
        for clave in claves:
            contenido = self.contenido(clave)
            if palabra in contenido:
                encontradas.push(clave)
                
        return encontradas
        
    def entradas (self):
        a = self.bd.keys()
        if not a:
            a = []
        return a

    def cierra (self):
        self.bd.close()

    def __len__(self):
        return len(self.entradas())
        
        
    def __setitem__ (self, clave, valor):
        self.bd[clave] = valor

    def __getitem__(self,clave):
        return self.bd[clave]

    def __delitem__(self,clave):
        del self.bd[clave]
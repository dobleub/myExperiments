import vtk

# Create a sphere source, mapper, and actor
esfera = vtk.vtkSphereSource()
esferaMapper = vtk.vtkPolyDataMapper()
esfera.SetPhiResolution(20)
esfera.SetThetaResolution(20)
esferaMapper.SetInput(esfera.GetOutput())
esferaActor = vtk.vtkActor()
esferaActor.SetMapper(esferaMapper)
esferaActor.GetProperty().SetColor(0,.50,1.0)
esferaActor.GetProperty().SetLineWidth(1)
# Create the Renderer, RenderWindow, RenderWindowInteractor
ren = vtk.vtkRenderer()
renWin = vtk.vtkRenderWindow()
renWin.AddRenderer(ren)
iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(renWin)

# Add the actors to the renderer; set the background and size; zoom
# in; and render.
ren.AddActor(esferaActor)

ren.SetBackground(1, 1, 1)
renWin.SetSize(350, 325)
ren.GetActiveCamera().Zoom(1.5)

iren.Initialize()
renWin.Render()
iren.Start()

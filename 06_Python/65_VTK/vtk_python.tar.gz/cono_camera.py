import vtk

# Generamos la estructura para ver un cono
cone = vtk.vtkConeSource()
coneMapper = vtk.vtkPolyDataMapper()
coneMapper.SetInput(cone.GetOutput())
coneActor = vtk.vtkActor()
coneActor.SetMapper(coneMapper)

# Creamos: Renderer, RenderWindow, RenderWindowInteractor
ren = vtk.vtkRenderer()
renWin = vtk.vtkRenderWindow()
renWin.AddRenderer(ren)
iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(renWin)

# Anhadimos el actor en el area de renderizado (Renderer)
ren.AddActor(coneActor)

renWin.SetSize(450,425)
ren.SetBackground(0.0, 0.0, 1)


ren.ResetCamera()
camera=ren.GetActiveCamera()
camera.Azimuth(60)
##camera.Azimuth(90)
##camera.Pitch(-15)
##camera.Yaw(15)
##camera.Roll(-65)
##camera.Elevation(-75)
##camera.Zoom(1.5)



iren.Initialize()
renWin.Render()
iren.Start()

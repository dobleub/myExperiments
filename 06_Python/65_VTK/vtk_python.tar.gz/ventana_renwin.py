import vtk


# Creamos: Renderer, RenderWindow, RenderWindowInteractor
ren = vtk.vtkRenderer()
renWin = vtk.vtkRenderWindow()
renWin.AddRenderer(ren)
iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(renWin)


iren.Initialize()
renWin.Render()
iren.Start()

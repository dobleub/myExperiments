import vtk

# Generamos la estructura para ver un cono
cone = vtk.vtkConeSource()
coneMapper = vtk.vtkPolyDataMapper()
coneMapper.SetInput(cone.GetOutput())
coneActor = vtk.vtkActor()
coneActor.SetMapper(coneMapper)

# Creamos: Renderer, RenderWindow, RenderWindowInteractor
ren = vtk.vtkRenderer()
renWin = vtk.vtkRenderWindow()
renWin.AddRenderer(ren)
iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(renWin)

# Anhadimos el actor en el area de renderizado (Renderer)
ren.AddActor(coneActor)

#Fijamos el color de fondo, el tamanho y hacemos zoom sobre
# el area de Renderizado
ren.SetBackground(0, 0, 1)
##renWin.SetSize(350, 225)

renWin.SetSize(450,425)
##ren.SetBackground(1.0, 0.0, 0)



conepro=coneActor.GetProperty()
conepro.SetColor(1,0.2,0)
conepro.SetOpacity(0.5)
conepro.SetLineWidth(3)
##conepro.SetRepresentationToWireframe()
##ren.ResetCamera()
camera=ren.GetActiveCamera()
camera.Zoom(1.5)


coneActor.RotateX(30)
coneActor.RotateY(45)
coneActor.SetScale([1,3,2])

cone.SetResolution(40)

iren.Initialize()
renWin.Render()
iren.Start()

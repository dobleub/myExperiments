from xml.dom import minidom
import urllib

DEFAULT_NAMESPACES = \
  (None, # RSS 0.91, 0.92, 0.93, 0.94, 2.0
  'http://purl.org/rss/1.0/', # RSS 1.0
  'http://my.netscape.com/rdf/simple/0.9/' # RSS 0.90
  )
DUBLIN_CORE = ('http://purl.org/dc/elements/1.1/',)

def load(rssURL):
  return minidom.parse(urllib.urlopen(rssURL))

def getElementsByTagName(node, tagName, possibleNamespaces=DEFAULT_NAMESPACES):
  for namespace in possibleNamespaces:
    children = node.getElementsByTagNameNS(namespace, tagName)
    if len(children): return children
  return []

def first(node, tagName, possibleNamespaces=DEFAULT_NAMESPACES):
  children = getElementsByTagName(node, tagName, possibleNamespaces)
  return len(children) and children[0] or None

def textOf(node):
  return node and "".join([child.data for child in node.childNodes]) or ""

if __name__ == '__main__':
  import sys
  rssDocument = load(sys.argv[1])
  fn = open('news.txt','w')
  Noticia=""
  for item in getElementsByTagName(rssDocument, 'item'):
    Noticia =  'Title: __' + textOf(first(item, 'title'))+ "__\n"
    Noticia = Noticia + 'Link: \n    '+ textOf(first(item, 'link'))+ "\n"
    Noticia = Noticia +  'Description: \n\n    ' + textOf(first(item, 'description'))+ "\n"
    Noticia = Noticia + '\nDate: ' + textOf(first(item, 'date', DUBLIN_CORE))+ "\n"
    Noticia = Noticia + '\nAuthor: '+ textOf(first(item, 'creator', DUBLIN_CORE))+ "\n"
    Noticia = Noticia + "---------------------------------------\n"
    fn.write(Noticia)
  fn.close()     
  
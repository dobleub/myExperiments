#!/usr/bin/jython

import javax.swing as swing
import java.lang as lang
import java.awt as awt
import java.util as util
import os



class Lector:   
        
    def exit(self, event):
        lang.System.exit(0)      

    def __init__(self): 

        self.vectorrss = util.Vector()
        self.vectorurl = util.Vector()
        self.listaRSS()
        self.listaNoticias()
        self.pnlBotones()
        self.menu() 
        if os.path.exists('listarss.txt'):
            self.leeFicheroRss()
        self.win = swing.JFrame("JyRss", size=(300, 300),windowClosing=self.exit)
        self.win.setJMenuBar(self.menu)
        self.win.contentPane.add(self.pnlBoton,awt.BorderLayout.NORTH)
        self.win.contentPane.add(self.jscplista, awt.BorderLayout.WEST)
        self.win.contentPane.add(self.jscpNoticias, awt.BorderLayout.CENTER)               
        self.win.setSize(600, 400)
        self.win.show()   
   
    def pnlBotones(self):        
        self.pnlBoton = swing.JPanel(awt.FlowLayout())
        acciones = ["A�adir","Borrar","Leer"]
        self.txtUrl = swing.JTextField(10) 
        lblNombre = swing.JLabel("Nombre") 
        self.txtNombre = swing.JTextField(10)
        lblUrl = swing.JLabel("Url")  
        self.pnlBoton.add(lblNombre)
        self.pnlBoton.add(self.txtNombre)
        self.pnlBoton.add(lblUrl)
        self.pnlBoton.add(self.txtUrl)
               
        for cadaBoton in acciones:
            self.pnlBoton.add(swing.JButton(cadaBoton, actionPerformed=self.accionMenu))
        
    
    def menu(self):
        opciones = ["Guardar"]
        self.menu = swing.JMenuBar()
        archivo = swing.JMenu("Archivo")
        for eachOpcion in opciones: 
            archivo.add(swing.JMenuItem(eachOpcion, actionPerformed=self.accionMenu))    
        self.menu.add(archivo)

    def listaRSS(self):
        self.lstLista = swing.JList()
        self.jscplista = swing.JScrollPane(self.lstLista)
        self.jscplista.setSize(100,100)
     
    def listaNoticias(self):
        self.lstNoticias = swing.JEditorPane()
        self.jscpNoticias = swing.JScrollPane(self.lstNoticias)
        
    def leeFicheroRss(self):                    
        f = open('listarss.txt','r')
        fu = open('listaurl.txt', 'r')        
        linea = f.readline()
        lurl = fu.readline()
        while linea:
            self.vectorrss.add(linea)
            self.vectorurl.add(lurl) 
            linea = f.readline()
            lurl = fu.readline()
        f.close()    
        fu.close()        
        self.lstLista.setListData(self.vectorrss)
    
    def leeFicheroNoticias(self):
        fg = open('news.txt','r')
        texto = fg.read()
        fg.close()            
        self.lstNoticias.setText(texto)
         
    def guardarFichero(self):
        fg = open('listarss.txt','w')
        furl = open('listaurl.txt','w')
        j = self.vectorrss.size()        
        i = 0
        while i<=j-1:
            texto = self.vectorrss.get(i)
            fg.write(texto +'\n')
            texto = self.vectorurl.get(i)
            furl.write(texto +'\n')
            i = i+1
        fg.close() 
        furl.close()
                       
    def accionMenu(self, event):
        self.accion = event.getActionCommand()
        if self.accion == 'A�adir':      
            if self.txtNombre.getText() == "":
                self.vectorrss.add("SIN NOMBRE\n")
            else:
                self.vectorrss.add(self.txtNombre.getText())      
            if self.txtUrl.getText() == "":
                self.vectorurl.add("SIN URL\n")
            else:     
                self.vectorurl.add(self.txtUrl.getText())
                
            self.lstLista.setListData(self.vectorrss) 
            self.txtNombre.setText("") 
            self.txtUrl.setText("")             
       
        elif self.accion == 'Leer':
            item = self.lstLista.getSelectedIndex()
            url = self.vectorurl.get(item)
            os.system('python lrss.py '+ url)
            self.leeFicheroNoticias()
            
        elif self.accion == 'Borrar':
            itemborrar = self.lstLista.getSelectedIndex()
            self.vectorrss.remove(itemborrar)
            self.vectorurl.remove(itemborrar)
            self.lstLista.setListData(self.vectorrss)

        elif self.accion == 'Guardar':
            self.guardarFichero()
            
root = Lector()

     
         
            
